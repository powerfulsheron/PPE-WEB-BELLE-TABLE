<?php

	$mdp = "AFGtr45jy(!m#io";
	
	if(strlen($mdp)>=6){
		echo "Le mot de passe au moins 6 caracteres <br/>";
	}
	
	if (preg_match('#^(?=.*[a-z])#', $mdp)){
		echo "Le mot de passe contient des minuscules <br/>";
	}
	
	if (preg_match('#^(?=.*[A-Z])#', $mdp)){
		echo "Le mot de passe contient des majuscules <br/>";
	}
	
	if (preg_match('#^(?=.*[0-9])#', $mdp)){
		echo "Le mot de passe contient des chiffres <br/>";
	}
	
	if (preg_match('#^(?=.*\W)#', $mdp)){
		echo "Le mot de passe contient des caracteres speciaux <br/>";
	}					

?>