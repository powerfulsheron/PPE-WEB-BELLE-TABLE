<?php

///////Fonction qui créé un tableau des jours fériés sur 3 ans///////
//Paramètre : Année de départ
function get_tab_joursferie($year) {

	$arr_bank_holidays = array(); // Tableau des jours feriés	
	
	for($i=0;$i<3;$i++) {//Parcours des jours fériés des 3 années
	
		// Liste des jours feriés
		$arr_bank_holidays[] = mktime(0, 0, 0, 1, 1, ($year+$i)); // Jour de l'an
		$arr_bank_holidays[] = mktime(0, 0, 0, 5, 1, ($year+$i)); // Fete du travail
		$arr_bank_holidays[] = mktime(0, 0, 0, 5, 8, ($year+$i)); // Victoire 1945
		$arr_bank_holidays[] = mktime(0, 0, 0, 7, 14, ($year+$i)); // Fete nationale
		$arr_bank_holidays[] = mktime(0, 0, 0, 8, 15, ($year+$i)); // Assomption
		$arr_bank_holidays[] = mktime(0, 0, 0, 11, 1, ($year+$i)); // Toussaint
		$arr_bank_holidays[] = mktime(0, 0, 0, 11, 11, ($year+$i)); // Armistice 1918
		$arr_bank_holidays[] = mktime(0, 0, 0, 12, 25, ($year+$i)); // Noel
				
		// Récupération de paques. Permet ensuite d'obtenir le jour de l'ascension et celui de la pentecote	
		$easter = easter_date(($year+$i));
		$easterDay   = date('d', $easter);
		$easterMonth = date('m', $easter);
		$easterYear   = date('Y', $easter);

		$arr_bank_holidays[] = mktime(0, 0, 0, $easterMonth, $easterDay + 2, $easterYear); // Paques
		$arr_bank_holidays[] = mktime(0, 0, 0, $easterMonth, $easterDay + 40, $easterYear); // Ascension
		$arr_bank_holidays[] = mktime(0, 0, 0, $easterMonth, $easterDay + 51, $easterYear); // Pentecote	
	}
	return $arr_bank_holidays;
}

///////Donne le nombre de jours ouvrés///////
//Paramètres : Mois voulu, année voulue
function get_tab_joursouvre($mois,$year) {

	$arr_bank_open = array(); // Tableau des jours ouvrés

	$nbjourmois = cal_days_in_month (CAL_GREGORIAN,$mois,$year); //Nombre de jours dans le mois
	
	$jours_feries = get_tab_joursferie($year); // Tableau des jours fériés (s'appuit sur la fonction au dessus)
	
	for($i=1;$i<$nbjourmois + 1;$i++) {//Parcours de tous les jours de mois
		
		$madatejour = date('Y-m-d 00:00:00',mktime(0, 0, 0, $mois,$i, $year));
		if(in_array($madatejour,$jours_feries)){} // Si la date est dans le tableau des jours férié (si la date est un jour férié)
		else{ //si la date n'est pas un jour férié
			if(date('N',mktime(0, 0, 0, $mois,$i, $year)) < '6'){ //Si la date n'est ni un un samedi (jour 6), ni un dimanche (jour 7)
				$arr_bank_open[] = $madatejour; //Ajout de la date au tableau des jours ouvrés
			}
		}
	}
	return $arr_bank_open;
}

///////Calculer la date a partir d'un interval de jours///////
//Paramètres : date de départ, interval de jours
function calculdate($date,$nbjour) {
	
	$tabdebut = date_parse($date);//Découpe la date dans un tableau associatif
	$my_year = $tabdebut['year'];//Récupération de l'année de la date découpée
	$my_month = $tabdebut['month'];//Récupération du mois de la date découpée
	$my_day = $tabdebut['day'];//Récupération du jour de la date découpée
	
	$datefin = date("Y-m-d 00:00:00", mktime(0, 0, 0, $my_month, ($my_day + $nbjour), $my_year));//Date recherchée

	return $datefin;
}

///////Calculer la date a partir d'un interval de jours (en respectant les jours ouvrés)///////
//Paramètres : date de départ, interval de jours
function calculdateouvre($date,$nbjour) {
	
	$tabdebut = date_parse($date);//Découpe la date dans un tableau associatif
	$my_year = $tabdebut['year'];//Récupération de l'année de la date découpée
	$my_month = $tabdebut['month'];//Récupération du mois de la date découpée
	$my_day = $tabdebut['day'];//Récupération du jour de la date découpée
	
	for($i=0;$i<$nbjour;$i++){
		$joursemaine = date("N" , mktime(0, 0, 0, $my_month, $my_day + $i , $my_year));//Permet d'obtenir le jour de la semaine (entre 1 et 7 : 1 étant lundi, 7 étant dimanche)
		
		$datenext = date("Y-m-d 00:00:00" , mktime(0, 0, 0, $my_month, $my_day + $i  , $my_year));//Donne la date suivante
		
		$tabfin = date_parse($datenext);//Découpe la date dans un tableau associatif
		$my_yearcalcul = $tabfin['year'];//Récupération de l'année de la date découpée
		
		if($joursemaine >= 6){//Si la date est un samedi ou un dimanche
			$nbjour = $nbjour + 1;//On ajoute une journée à la durée initiale
		}
		else{
			$montableau = get_tab_joursferie($my_yearcalcul);// Tableau des jours fériés (s'appuit sur la fonction au dessus)
			if(in_array($datenext,$montableau) == true){ //Si la date est un jour férié
				$nbjour = $nbjour + 1;//On ajoute une journée à la durée initiale
			}
		}
	}
	
	$datefin = date("Y-m-d 00:00:00", mktime(0, 0, 0, $my_month, $my_day + ($i-1) , $my_year));//Date recherchée
	
	return $datefin;
}
