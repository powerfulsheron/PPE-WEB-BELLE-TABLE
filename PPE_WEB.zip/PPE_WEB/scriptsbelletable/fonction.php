<?php
include('parametres.php');

function AjoutZero($string){
	$constant = $string;
	if(strlen($string)<5){	
		$string = '0'.$string;
		for($i=strlen($constant);$i<4;$i++){
			$string = '0'.$string;
		}
	}
	return $string;
}

function CalculDeltaDate($madate){
	$datejours = date('Y-m-d H:i:s');
	$intervale = $datejours->diff($madate)->format('%d;%m;%y;%h;%i;%s');
	list($nbj, $nbm, $nba,$nbh,$nbmn,$nbs) = split('[;.-]', $intervale);
	if($nba < 0){
		if($nbm < 0){
			if($nbj < 0){
				if($nbh > 1){
					return false;
				}
				else{
					return true;
				}
			}
			else{
				return false;
			}
		}
		else{
			return false;	
		}
	}
	else{
		return false;		
	}
}



?>
